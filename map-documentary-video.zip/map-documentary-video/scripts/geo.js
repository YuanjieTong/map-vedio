// usage: node geo.js OUT.json lonMin lonMax latMin latMax id1 id2 ...   (ISO numeric ids, e.g. 408 PRK, 410 KOR, 156 CHN, 392 JPN, 643 RUS)
// needs: npm i world-atlas topojson-client   -> {id:[ring,...]} outer rings touching the bbox
const t=require('topojson-client'),w=require('world-atlas/countries-10m.json'),fs=require('fs');
const [out,x0,x1,y0,y1,...ids]=process.argv.slice(2);const fc=t.feature(w,w.objects.countries),o={};
for(const f of fc.features){if(!ids.includes(String(f.id)))continue;
 const polys=f.geometry.type==='Polygon'?[f.geometry.coordinates]:f.geometry.coordinates,rings=[];
 for(const p of polys){const r=p[0];if(r.some(c=>c[0]>+x0&&c[0]<+x1&&c[1]>+y0&&c[1]<+y1))rings.push(r.map(c=>[+c[0].toFixed(4),+c[1].toFixed(4)]));}
 o[f.id]=rings;console.log(f.id,f.properties.name,rings.length);}
fs.writeFileSync(out,JSON.stringify(o));
