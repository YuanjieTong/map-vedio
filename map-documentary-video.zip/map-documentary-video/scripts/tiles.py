import math,os,subprocess,json,sys
from concurrent.futures import ThreadPoolExecutor
import numpy as np
from PIL import Image, ImageFilter
def xy(lon,lat,z):
    n=2**z;x=(lon+180)/360*n
    y=(1-math.asinh(math.tan(math.radians(lat)))/math.pi)/2*n
    return x,y
def fetch(a):
    url,path=a
    if os.path.exists(path) and os.path.getsize(path)>300: return
    for i in range(4):
        subprocess.run(["curl","-sS","-m","40","-o",path,url],capture_output=True)
        if os.path.exists(path) and os.path.getsize(path)>300: return
# usage: python3 tiles.py layers_config.json OUT_DIR   (tiles are cached in ./tiles)
# config: {"L0":[zoom,lon0,lon1,lat0,lat1,hillshade(bool)], ...}  coarse -> fine
LAYERS={k:tuple(v) for k,v in json.load(open(sys.argv[1])).items()}
OUT=sys.argv[2];os.makedirs(OUT,exist_ok=True);os.makedirs("tiles",exist_ok=True)
BM=None
def bm_crop(x0,y0,x1,y1,W,H):
    global BM
    Z=8;n=2**Z
    if BM is None:
        los=[v[1] for v in LAYERS.values()]+[v[2] for v in LAYERS.values()];las=[v[3] for v in LAYERS.values()]+[v[4] for v in LAYERS.values()]
        ax,ay=xy(min(los),max(las),Z);bx,by=xy(max(los),min(las),Z);A,B,C,D=int(ax)-1,int(bx)+1,int(ay)-1,int(by)+1
        jobs=[(f"https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/BlueMarble_ShadedRelief_Bathymetry/default/GoogleMapsCompatible_Level8/{Z}/{y}/{x}.jpeg",f"tiles/bm_{Z}_{x}_{y}.jpg") for x in range(A,B+1) for y in range(C,D+1)]
        with ThreadPoolExecutor(8) as ex: list(ex.map(fetch,jobs))
        im=Image.new("RGB",((B-A+1)*256,(D-C+1)*256));bad=0
        for x in range(A,B+1):
            for y in range(C,D+1):
                try: im.paste(Image.open(f"tiles/bm_{Z}_{x}_{y}.jpg").convert("RGB"),((x-A)*256,(y-C)*256))
                except Exception: bad+=1
        print("blue marble",im.size,"bad",bad);BM=(im,A/n,C/n,(B+1)/n,(D+1)/n)
    im,a0,c0,a1,c1=BM;sx=im.width/(a1-a0);sy=im.height/(c1-c0)
    box=((x0-a0)*sx,(y0-c0)*sy,(x1-a0)*sx,(y1-c0)*sy)
    return np.asarray(im.resize((W,H),Image.BICUBIC,box=box)).astype(np.float32)/255
meta={}
for name,(z,lo0,lo1,la0,la1,hs) in LAYERS.items():
    x0,y0=xy(lo0,la1,z);x1,y1=xy(lo1,la0,z)
    X0,X1,Y0,Y1=int(x0),int(x1),int(y0),int(y1)
    jobs=[]
    for x in range(X0,X1+1):
        for y in range(Y0,Y1+1):
            jobs.append((f"https://tiles.maps.eox.at/wmts/1.0.0/s2cloudless_3857/default/g/{z}/{y}/{x}.jpg",f"tiles/s_{z}_{x}_{y}.jpg"))
            if hs: jobs.append((f"https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png",f"tiles/t_{z}_{x}_{y}.png"))
    with ThreadPoolExecutor(8) as ex: list(ex.map(fetch,jobs))
    W=(X1-X0+1)*256;H=(Y1-Y0+1)*256
    sat=Image.new("RGB",(W,H));el=np.zeros((H,W),np.float32)
    bad=0
    for x in range(X0,X1+1):
        for y in range(Y0,Y1+1):
            try: sat.paste(Image.open(f"tiles/s_{z}_{x}_{y}.jpg").convert("RGB"),((x-X0)*256,(y-Y0)*256))
            except Exception: bad+=1
            if hs:
                try:
                    t=np.asarray(Image.open(f"tiles/t_{z}_{x}_{y}.png").convert("RGB")).astype(np.float32)
                    el[(y-Y0)*256:(y-Y0+1)*256,(x-X0)*256:(x-X0+1)*256]=t[...,0]*256+t[...,1]+t[...,2]/256-32768
                except Exception: bad+=1
    a=np.asarray(sat).astype(np.float32)/255
    # grade: lift shadows, slight desaturation
    if hs:
        a=np.clip(a*1.35+0.03,0,1)**0.85
        g=a.mean(2,keepdims=True);a=g+(a-g)*0.9
    else:  # close-up layers without relief: add contrast instead of brightening (otherwise washed out)
        a=np.clip((a*1.35+0.03-0.12)*1.25,0,1)**1.0
        g=a.mean(2,keepdims=True);a=g+(a-g)*1.2
    if hs=='bm':   # colour from NASA Blue Marble (seamless, public domain), relief from the elevation tiles
        a=bm_crop(X0/2**z,Y0/2**z,(X1+1)/2**z,(Y1+1)/2**z,W,H)
        a=np.clip(a*1.5+0.04,0,1)**0.85
        g=a.mean(2,keepdims=True);a=g+(a-g)*1.05
        a=np.where((el>0.5)[...,None],a,a*np.array([.42,.55,.72],np.float32))
    if hs=='flat':  # flat-colour land + relief (no satellite texture): land beige, sea blue darkening with depth
        landm=(el>0.5)[...,None]
        depth=np.clip(1+el/5000,0.55,1)[...,None]
        a=np.where(landm,np.array([0.80,0.775,0.70],np.float32),np.array([0.13,0.30,0.52],np.float32)*depth)
    if hs:
        el=np.maximum(el,0)
        res=40075016/(2**z*256)*math.cos(math.radians((la0+la1)/2))
        ex_={6:9,7:7.5,8:6,9:4.4,10:3.2,11:2.7,12:2.2,13:1.8,14:1.5}.get(z,2)
        dy,dx=np.gradient(el*ex_/res)
        az,alt=math.radians(315),math.radians(42)
        slope=np.arctan(np.hypot(dx,dy));asp=np.arctan2(dy,-dx)
        sh=np.sin(alt)*np.cos(slope)+np.cos(alt)*np.sin(slope)*np.cos(az-math.pi/2-asp)
        sh=np.clip(sh/math.sin(alt),0,1.6)
        a=np.clip(a*(0.35+0.65*sh[...,None]),0,1)
    a=np.clip(a,0,1)
    out=Image.fromarray((a*255).astype(np.uint8))
    out.save(f"{OUT}/{name}.jpg",quality=88)
    n=2**z
    meta[name]=dict(x0=X0/n,y0=Y0/n,x1=(X1+1)/n,y1=(Y1+1)/n,w=W,h=H)
    print(name,W,H,"bad",bad)
json.dump(meta,open(f"{OUT}/layers.json","w"))
