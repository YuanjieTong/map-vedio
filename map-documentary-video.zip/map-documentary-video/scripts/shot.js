// usage: node shot.js out.jpg t1 t2 ...  -> contact sheet pieces
const {chromium}=require('playwright'),fs=require('fs');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1080,height:1920}});
 p.on('console',m=>console.log('PAGE:',m.text()));p.on('pageerror',e=>console.log('ERR:',e.message));
 await p.goto('http://localhost:8765/index.html');await p.waitForFunction('window.ready',{timeout:60000});
 const pre=process.argv[2];for(const t of process.argv.slice(3)){const d=await p.evaluate(t=>window.frame(t),parseFloat(t));
  fs.writeFileSync(`${pre}_${t}.jpg`,Buffer.from(d.split(',')[1],'base64'));}
 await b.close();})();
