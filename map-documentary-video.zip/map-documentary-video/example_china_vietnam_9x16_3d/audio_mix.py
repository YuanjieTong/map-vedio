import argparse
import json
import subprocess
import wave

import numpy as np
SR=44100
def load(path):
    result = subprocess.run(
        ["ffmpeg", "-v", "error", "-i", path, "-f", "f32le", "-ac", "2", "-ar", str(SR), "-"],
        capture_output=True,
    )
    if result.returncode or not result.stdout:
        detail = result.stderr.decode(errors="replace").strip()
        raise ValueError(detail or f"No audio decoded from {path}")
    return np.frombuffer(result.stdout, dtype="<f4").reshape(-1, 2).copy()


parser = argparse.ArgumentParser(description="Mix narration with optional music and timed sound effects.")
parser.add_argument("voice", help="Narration audio")
parser.add_argument("--music", help="Optional licensed music track, prepared for the scene")
parser.add_argument("--events", help="Optional JSON array of sound effects")
parser.add_argument("--output", default="mix.wav")
args = parser.parse_args()
try:
    voice = load(args.voice)
except ValueError as error:
    parser.error(str(error))
N = len(voice)

rng=np.random.default_rng(7)
def band(n,lo,hi):
    x=rng.normal(0,1,n);X=np.fft.rfft(x);f=np.fft.rfftfreq(n,1/SR);m=1/(1+(f/hi)**4);
    if lo>0:m*=1-1/(1+(f/lo)**4)
    y=np.fft.irfft(X*m,n);return y/ (np.abs(y).max()+1e-9)
def boom(size=1.0,far=False):
    d=1.6 if far else 1.2;n=int(d*SR);t=np.arange(n)/SR
    nz=band(n,0,90 if far else 220)*np.exp(-t*(3 if far else 4.5))
    th=np.sin(2*np.pi*(38*t+ (70-38)/7*(1-np.exp(-7*t))))*np.exp(-t*5)
    cr=band(n,300,2500)*np.exp(-t*18)*(0.0 if far else 0.25)
    y=np.tanh((nz*0.9+th*0.8+cr)*1.4)*size*(0.45 if far else 1.0)
    y[:60]*=np.linspace(0,1,60);return y
def crack():
    n=int(0.09*SR);t=np.arange(n)/SR;return band(n,900,4500)*np.exp(-t*60)*0.5
def tank(d):
    n=int(d*SR);t=np.arange(n)/SR;saw=lambda f:2*((t*f)%1)-1
    y=(saw(37)*0.5+saw(74.3)*0.25+np.sin(2*np.pi*18.5*t)*0.5)*(0.75+0.25*np.sin(2*np.pi*11*t))+band(n,60,900)*0.35
    X=np.fft.rfft(y);f=np.fft.rfftfreq(n,1/SR);y=np.fft.irfft(X/(1+(f/500)**2),n)
    e=np.minimum(1,np.minimum(t/0.8,(d-t)/1.0));return y/np.abs(y).max()*e
sfx=np.zeros((N,2),np.float32)
def put(y,at,g=1.0,pan=0.0):
    i=int(at*SR);j=min(N,i+len(y));
    if i>=N or i<0:return
    l=g*np.sqrt((1-pan)/2*2)*0.7;r=g*np.sqrt((1+pan)/2*2)*0.7
    sfx[i:j,0]+=y[:j-i]*l;sfx[i:j,1]+=y[:j-i]*r
if args.events:
    with open(args.events, encoding="utf-8") as event_file:
        events = json.load(event_file)
    for event in events:
        kind = event["type"]
        at = float(event["at"])
        if kind == "boom":
            sound = boom(far=event.get("far", False))
        elif kind == "crack":
            sound = crack()
        elif kind == "tank":
            duration = float(event.get("duration", 3))
            if duration <= 0:
                parser.error("Tank sound duration must be positive.")
            sound = tank(duration)
        else:
            parser.error(f"Unknown sound effect: {kind}")
        put(sound, at, float(event.get("gain", 1)), float(event.get("pan", 0)))


def rms(signal):
    return np.sqrt(np.mean(signal ** 2))


active = voice[np.abs(voice).max(axis=1) > 0.02]
voice_level = rms(active if active.size else voice)
if voice_level > 0:
    voice *= 0.16 / voice_level

mix = voice.copy()
if args.music:
    try:
        music = load(args.music)[:N]
        level = rms(music)
        if level <= 0:
            raise ValueError("Music is silent.")
    except ValueError as error:
        print(f"Music omitted: {error}")
    else:
        t = np.arange(len(music)) / SR
        fade = np.minimum(np.clip(t / 1.5, 0, 1), np.clip((t[-1] - t) / 2.5, 0, 1))
        music *= fade[:, None] * (0.16 * 10 ** (-21 / 20) / level)
        mix[:len(music)] += music
        print(f"Music used: {args.music}")

peak_sfx = np.abs(sfx).max()
if peak_sfx > 0.10:
    sfx *= 0.10 / peak_sfx
mix += sfx
peak = np.abs(mix).max()
if peak > 0.98:
    mix *= 0.98 / peak
with wave.open(args.output, "wb") as output:
    output.setnchannels(2)
    output.setsampwidth(2)
    output.setframerate(SR)
    output.writeframes((mix * 32767).astype("<i2").tobytes())
