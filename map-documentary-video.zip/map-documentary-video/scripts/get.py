import sys,subprocess,time,json
sys.path.insert(0,'.')
from wm import api,UA
items=dict(l.split("=",1) for l in sys.argv[1:])
def q(titles,w):
    for i in range(8):
        r=api(dict(action="query",titles="|".join(titles),prop="imageinfo",iiprop="url|extmetadata|size",iiurlwidth=w,format="json"))
        if "query" in r: return r["query"]
        time.sleep(10)
    return {}
meta={}
for w,sel in ((330,[k for k,v in items.items() if v.startswith("File:Flag")]),(1280,[k for k,v in items.items() if not v.startswith("File:Flag")])):
    if not sel: continue
    r=q([items[k] for k in sel],w)
    norm={n["from"]:n["to"] for n in r.get("normalized",[])}
    pages={p["title"]:p for p in r.get("pages",{}).values()}
    for k in sel:
        p=pages.get(norm.get(items[k],items[k]))
        if not p or "imageinfo" not in p: print("MISSING",k);continue
        ii=p["imageinfo"][0];m=ii["extmetadata"]
        url=ii.get("thumburl") or ii["url"]
        ext=".png" if url.split("?")[0].lower().endswith(".png") else ".jpg"
        for i in range(6):
            subprocess.run(["curl","-sS","-L","-m","90","-A",UA,"-o",f"assets/{k}{ext}",url])
            if b"image" in subprocess.run(["file","-b","--mime",f"assets/{k}{ext}"],capture_output=True).stdout: break
            time.sleep(6*(i+1))
        meta[k]=dict(title=items[k],license=m.get("LicenseShortName",{}).get("value"),credit=m.get("Credit",{}).get("value","")[:200],page=ii.get("descriptionurl"))
        print(k,ext,"|",meta[k]["license"]);time.sleep(2)
old=json.load(open("assets/meta.json")) if __import__("os").path.exists("assets/meta.json") else {}
old.update(meta);json.dump(old,open("assets/meta.json","w"),indent=1,ensure_ascii=False)
