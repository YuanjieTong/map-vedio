sheet () 
{ 
    name=$1;
    shift;
    node shot.js shots/f "$@" && python3 - "$name" "$@" <<'E'
import sys
from PIL import Image
n=sys.argv[1];ts=sys.argv[2:]
ims=[Image.open(f"shots/f_{t}.jpg").resize((360,640)) for t in ts]
s=Image.new("RGB",(360*len(ims),640))
for i,im in enumerate(ims): s.paste(im,(i*360,0))
s.save(f"shots/{n}.jpg",quality=85)
E

}
