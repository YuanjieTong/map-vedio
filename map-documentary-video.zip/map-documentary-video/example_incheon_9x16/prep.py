# EXAMPLE (Incheon): turns downloaded Commons images in assets/ into build/ files.
# Rewrite the crop boxes / file names per video. Run from the project dir.
import numpy as np, json, math
from PIL import Image, ImageFilter, ImageOps
B="build/"
# paper map
im=Image.open("assets/mapen.png").convert("RGBA")
bg=Image.new("RGBA",im.size,(255,255,255,255));bg.alpha_composite(im)
a=np.asarray(bg.convert("RGB")).astype(np.float32)[:, :1100]
sea=(a[...,2]-a[...,0])>22
rng=np.random.default_rng(1)
noise=rng.normal(0,1,(a.shape[0]//4+1,a.shape[1]//4+1))
noise=np.asarray(Image.fromarray(((noise*20)+128).clip(0,255).astype(np.uint8)).resize((a.shape[1],a.shape[0]),Image.BICUBIC)).astype(np.float32)-128
g=a.mean(2)
out=np.zeros_like(a)
land=np.array([236,226,200],np.float32);seac=np.array([176,198,206],np.float32)
ink=np.clip((235-g)/150,0,1)  # dark ink strength
base=np.where(sea[...,None],seac,land)
# sea pixels: g high ~ 230; ink only where really dark
ink=np.where(sea,np.clip((200-g)/120,0,1),np.clip((225-g)/140,0,1))
out=base*(1-ink[...,None])+np.array([40,36,32],np.float32)*ink[...,None]
out=np.clip(out+noise[...,None]*0.5,0,255)
# vignette
h,w=g.shape;yy,xx=np.mgrid[0:h,0:w];v=1-0.18*(((xx/w-.5)**2+(yy/h-.5)**2)*2)
Image.fromarray((out*v[...,None]).clip(0,255).astype(np.uint8)).save(B+"paper.jpg",quality=92)
m=Image.fromarray((sea*255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(1.2))
mud=Image.new("RGBA",(w,h),(122,98,66,255));mud.putalpha(m);mud.save(B+"mud.png")
# photos
def save(src,dst,box=None,maxw=1100,gray=False):
    i=Image.open(src).convert("RGB")
    if box: i=i.crop(box)
    if gray: i=ImageOps.autocontrast(ImageOps.grayscale(i),cutoff=1).convert("RGB")
    if i.width>maxw: i=i.resize((maxw,int(i.height*maxw/i.width)),Image.LANCZOS)
    i.save(B+dst,quality=90);print(dst,i.size)
save("assets/mac.jpg","mac.jpg",(60,40,1240,960),800,True)
save("assets/kim.jpg","kim.jpg",(60,150,1240,1070),800,True)
save("assets/lst.jpg","lst.jpg",(8,8,1272,1017),1000,True)
save("assets/lopez.jpg","lopez.jpg",(0,60,1280,1560),900,True)
save("assets/mac_ship.jpg","mac_ship.jpg",None,1000,True)
for f in ["nk","sk","us","un","cn"]:
    Image.open(f"assets/f_{f}.png").convert("RGB").save(B+f"f_{f}.png")
