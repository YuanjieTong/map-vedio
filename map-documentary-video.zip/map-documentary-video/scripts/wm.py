import sys,json,urllib.parse,subprocess
UA="MapDocumentaryVideo/1.0"
def api(params):
    u="https://commons.wikimedia.org/w/api.php?"+urllib.parse.urlencode(params)
    import time
    for i in range(6):
        o=subprocess.run(["curl","-sS","-m","30","-A",UA,u],capture_output=True,text=True).stdout
        try: return json.loads(o)
        except Exception: time.sleep(4*(i+1))
    return {}
def search(q,n=8):
    r=api(dict(action="query",generator="search",gsrsearch=q,gsrnamespace=6,gsrlimit=n,prop="imageinfo",iiprop="url|size|extmetadata",iiurlwidth=1280,format="json"))
    for p in sorted(r.get("query",{}).get("pages",{}).values(),key=lambda p:p.get("index",0)):
        ii=p["imageinfo"][0];m=ii["extmetadata"]
        print(p["title"],"|",ii["width"],"x",ii["height"],"|",m.get("LicenseShortName",{}).get("value"),"|",ii.get("thumburl"))
if __name__=="__main__":
    for q in sys.argv[1:]:
        print("##",q);search(q);__import__("time").sleep(2)
