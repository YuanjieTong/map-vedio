import argparse
import json
import wave

import numpy as np
from faster_whisper import WhisperModel

parser = argparse.ArgumentParser()
parser.add_argument("wav")
parser.add_argument("--model", default="small")
parser.add_argument("--language")
parser.add_argument("--output", default="words.json")
args = parser.parse_args()

with wave.open(args.wav) as audio_file:
    if (audio_file.getframerate(), audio_file.getnchannels(), audio_file.getsampwidth()) != (16000, 1, 2):
        parser.error("Input must be 16 kHz mono 16-bit PCM WAV.")
    audio = np.frombuffer(audio_file.readframes(audio_file.getnframes()), dtype="<i2")
    audio = audio.astype(np.float32) / 32768

model = WhisperModel(args.model, device="cpu", compute_type="int8")
segments, _ = model.transcribe(audio, language=args.language, word_timestamps=True)
words = []
for segment in segments:
    print(f"{segment.start:.2f}-{segment.end:.2f} {segment.text}")
    for word in segment.words:
        words.append({"w": word.word.strip(), "s": round(word.start, 2), "e": round(word.end, 2)})
with open(args.output, "w", encoding="utf-8") as output:
    json.dump(words, output, ensure_ascii=False)
