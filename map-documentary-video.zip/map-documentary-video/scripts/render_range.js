// usage: node render_range.js URL WIDTH HEIGHT startFrame endFrame outPrefix
const {chromium}=require('playwright'),{spawn}=require('child_process');
const [url,W,H,A,B,pre]=process.argv.slice(2),FPS=30,K=2,a0=+A,b0=+B;
async function worker(i){const a=a0+Math.floor((b0-a0)*i/K),b=a0+Math.floor((b0-a0)*(i+1)/K);
 const ff=spawn('ffmpeg',['-y','-v','error','-f','image2pipe','-c:v','mjpeg','-framerate',String(FPS),'-i','-','-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p','-r',String(FPS),`${pre}${i}.mp4`],{stdio:['pipe','inherit','inherit']});
 const br=await chromium.launch();const p=await br.newPage({viewport:{width:+W,height:+H}});p.on('pageerror',e=>console.log('ERR',e.message));
 await p.goto(url);await p.waitForFunction('window.ready',{timeout:60000});
 for(let f=a;f<b;f++){const d=await p.evaluate(t=>window.frame(t),f/FPS);if(!ff.stdin.write(Buffer.from(d.slice(23),'base64')))await new Promise(r=>ff.stdin.once('drain',r));}
 ff.stdin.end();await new Promise(r=>ff.on('close',r));await br.close();}
Promise.all([...Array(K).keys()].map(worker)).then(()=>console.log('done'));
