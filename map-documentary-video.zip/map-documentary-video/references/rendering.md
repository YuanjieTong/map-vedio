# 转写和渲染

先确认当前环境可用的网络、Python、Node、FFmpeg 和 Playwright Chromium。用小范围瓦片和几帧试跑估算耗时。优先读取项目附件中的现成素材。网页能打开来源页时，还需单独确认执行环境实际能下载文件。

有带时间码的逐字稿或词级时间 JSON 时优先使用。否则把音轨转为 16 kHz 单声道 16-bit PCM WAV，再运行 `python scripts/tr.py audio.wav --model small`（需要 faster-whisper 及模型）。按旁白语言指定 `--language`，例如 `en` 或 `zh`，也可让模型识别。默认输出 `words.json`，每项形如 `{"w":"词","s":0.1,"e":0.5}`。无字幕时仍需旁白时间轴。只有无时间码稿时，可给分镜用的估算时间并标明，实际成片同步需要验证。

以 `example_china_vietnam_9x16_3d/index.html` 为两遍渲染参考。横屏参考 `example_incheon_16x9/` 的布局，若保留 3D，需调整画布、投影和 HUD，单改 Playwright viewport 不会改变画布。旧版竖屏只用于查函数。范例的日期、照片、事件、坐标和资产清单均需按新项目重写。省略字幕时可提供空的 `words.json`（`[]`）给页面。放入实际引用的图片和字体，并核对启动时的文件加载错误。

1. **底图**：写 `layers_config.json`（由粗到细 3–4 层），跑 `scripts/tiles.py config.json build/`。每层第 6 项是模式：
   - `true`：颜色用 EOX Sentinel-2 cloudless 2016（CC BY 4.0，可商用，需署名）+ 高程阴影。默认优先使用此模式。它每一层都是该缩放级别的真实影像，所以拉近后依然清晰；z14 是清晰度上限。参考分层（朝鲜半岛竖屏）：L0 z8 全景（范围比全景镜头每边多出 8–10°）、L1 z10 整个国家、L2/L3 z11 战区和特写区。近海会有灰白色的影像拼接块，这是正常的；华南等地区在中低缩放有大块云雪拼接痕，生成后先看图，某一层太脏时只把那一层换成 `"bm"`。
   - `"bm"`：颜色用 NASA Blue Marble（公有领域、无拼接痕）+ 高程阴影。只有 z8 一个分辨率，拉近后颜色是放大的、发糊，海面是饱和的亮蓝。只在 Sentinel-2 某层拼接痕太重时作为替补。
   - `"flat"`：纯色平涂，仅在用户明确接受时采用。
   倾斜后能看到更远，每层范围要比俯视时多留一圈，否则顶部露出模糊带。出现 `bad N` 先检查成图，清除失败的缓存瓦片再重试。少量海上高程瓦片缺失且无可见影响时可继续。
2. **国界和字体**：`npm i world-atlas topojson-client @fontsource/montserrat @fontsource/barlow-condensed @fontsource/anton`；`node geo.js build/geo.json lonMin lonMax latMin latMax <ISO数字id…>`（geo.js 要放在有 node_modules 的目录里跑）；把 5 个 woff2 拷进 `build/`。
3. **写场景**：复制范例到 `build/index.html`，保留通用函数，重写：`CAMK`（镜头 [起,止,经,纬,视野宽度°]）、`PITCH`/`YAWK`（按风格规则 4 取值，保持克制）、`LOBE`/`LK`（推进范围：起始线在进攻方境内，终止线是最大推进线，按时间进退）、地点常量、`vsCard`、`DATES`、`SECS`、`scene(t)`、`INS`（小照片）、`FIX`。
   - `scene(t)` 会被调用两遍：第 1 遍画贴地的（`arrow/dashLine/ring/river` 和直接调用的 `txt`），第 2 遍画立着的（`flag/troop/boom/flashes/tag/tank/person/bigStat/inset`）。地理位置一律用 `P(lon,lat)`，不要用 `sx()/sy()`，也不要写死像素偏移；自己直接用 `ctx` 画的东西要加 `if(PASS===1)` 或 `PASS===2`。
   - 随军头像用 `person` 在 `scene(t)` 的第二遍绘制，沿用所属部队的地图位置。人物资料卡在 `render()` 的 HUD 阶段用屏幕坐标绘制。两者分别按分镜时间控制。
   - 常量名不要和 `PASS/PROJ/DEPTH/TH/YAW/C0` 冲突。
   - 图层淡入阈值 `thr` 随版面和层数调整（层要在镜头视野小于其范围时才淡入）。
4. **预览**：`cd build && python3 -m http.server 8767 &`（必须走 http，file:// 会污染 canvas）。每次渲染前检查服务器和端口。用 `shot.js`（改端口和 viewport）每 2–3 秒抽一帧拼图检查：重叠、标签被挡、照片是否压住动作、头像位置、层边缘、颜色异常；特写点要放大原图确认坐标。
5. **渲染**：`node scripts/render_range.js http://localhost:8767/index.html <宽> <高> 0 <总帧数=ceil(音频秒×30)> vseg`，先试跑短段，按实际运行时限分段，记录每段帧范围并保留已验证的片段。每段会生成两个按时间排序的 MP4，用 ffprobe 核实帧数及解码状态后再拼接。只想看某段效果时给起止帧，音频用 `-ss/-t` 截同一段。

6. **合成**：按帧范围顺序拼接各段，用最终混音轨合成 H.264/AAC MP4，30fps，像素格式 yuv420p，启用 faststart。核对时长、分辨率、音轨、首尾和分段接点。片尾底图署名画在 `render()` 的 HUD，放在字幕之后。

## 已知坑

- 交叉网格的 `mkHatch`：14px 图案，线宽 1.3、`rgba(255,255,255,.17)`，画两个方向的斜线；范例里的 `mkHatch` 占两行，替换时两行一起换，否则脚本语法错误、页面一直不 ready。
- 四层 Sentinel-2 大图（每张 25–40 MP）加载较慢，`shot.js` 等待 `window.ready` 超时先查页面报错，不是就把超时加长。
- 多层底图边界会露出矩形（Sentinel-2 不同缩放的海面颜色不一样，海上更明显）：细层只在足够拉近时淡入并做边缘羽化（`drawBase` 已处理），层范围要大于镜头视野。
- 推进范围多边形用“推进线 + 绕进攻方一侧外框闭合”，再裁剪到被进攻国的陆地；起止两条线先重采样到同样点数再插值。
- 3D 的地面画布（`GW×GH`）和虚拟画布 `VS` 要盖住俯仰角最大时屏幕顶部对应的地面范围；俯仰超过约 32° 顶部会出黑边。
- 倾斜后跑到画面边缘的地名标签会露半截，检查顶部和两侧。
- 抽查随军头像是否随部队移动并保持清晰。检查横竖屏左下角的资料卡是否遮住字幕、重要地名或部队动作，并确认同屏的随军头像仍可辨认。
- 引言、宽标签、时钟出现在顶部时，注意别和章节牌重叠。
- 载具是侧视图放在俯视地图上，拉近镜头时按视野缩小，别挡住标签。
- 斜线纹理会提高码率。根据成片画质和交付大小调整编码，必要时另做低分辨率预览。
